# LocalFix upgrade starter + Paystack checkout integration

This package is a **deployable integration starter**, not a live change to `localfixxx.netlify.app`. It adds a Netlify Function that initializes Paystack checkout, a signed Paystack webhook that verifies the transaction server-side, and a 10% LocalFix commission ledger. It has not been deployed or tested against your live Supabase project.

## What's included
- `index.html` — LocalFix frontend with Supabase Auth, provider search/profile UI, booking requests, admin summary, and Pay button for accepted/in-progress bookings with an agreed price.
- `supabase/schema.sql` — Supabase schema and RLS policies.
- `netlify/functions/paystack-initialize.mjs` — checks the signed-in customer and booking on the server, uses the database's agreed price (never a browser-submitted price), records a pending payment, then requests Paystack checkout.
- `netlify/functions/paystack-webhook.mjs` — validates Paystack's HMAC signature, verifies the transaction with Paystack, checks the exact NGN amount, then marks the ledger payment paid. Repeat webhook events are idempotently ignored after a payment is marked paid.
- `payment-return.html` — neutral return page; it does not assume payment succeeded.
- `netlify.toml` — publishes the static site and configures Netlify Functions.

## Setup checklist

### 1. Supabase
1. Open https://supabase.com/dashboard and select your project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In `index.html`, set the existing `SUPABASE_URL` and `SUPABASE_ANON_KEY` constants to your Supabase project URL and public/anon key.
4. Configure Supabase Auth site URL and redirect URLs for your Netlify domain.
5. Make sure providers/admins can set `bookings.agreed_amount_ngn` only through a trusted/authorized workflow. The customer cannot choose the amount in the payment request.

### 2. Paystack test mode first
1. Create/open your Paystack account at https://paystack.com/ and use **Test Mode** initially.
2. Copy your **test secret key** from the Paystack dashboard. Never paste it into `index.html`, SQL, Git, or chat.
3. Do not use live mode until you have tested successful, failed, duplicate, wrong-amount, and abandoned payments.

### 3. Netlify environment variables
In Netlify: **Site configuration → Environment variables** (the exact menu label can vary), add these values for Functions:
- `SUPABASE_URL` = your Supabase project URL
- `SUPABASE_ANON_KEY` = your Supabase public/anon key
- `SUPABASE_SERVICE_ROLE_KEY` = your Supabase service-role/secret key (secret; server-side only)
- `PAYSTACK_SECRET_KEY` = your Paystack test secret key initially (secret; server-side only)
- `SITE_URL` = your full Netlify URL, e.g. `https://your-site-name.netlify.app`

Set secret values only in Netlify's environment-variable settings, not in the frontend or a committed `.env` file. Redeploy after changing variables.

### 4. Configure Paystack webhook
In Paystack dashboard's API/webhook settings, set the webhook URL to:
`https://YOUR-NETLIFY-DOMAIN/.netlify/functions/paystack-webhook`

Use the exact deployed domain. Paystack signs webhook payloads with your secret key; the function checks the signature and separately verifies the transaction before updating Supabase.

### 5. Deploy manually to Netlify
Because Netlify Functions need a project directory and a build/deploy that includes the `netlify/functions` folder, do **not** upload only `index.html`. Extract this ZIP, keep the folder structure, and deploy the entire project folder using Netlify's supported manual deploy workflow or Netlify CLI. Confirm the deployed Functions appear in Netlify. If your current site contains other files, merge these additions into a backup/copy of the existing site first so you do not overwrite pages/assets unintentionally.

## How the 10% commission works
The server records `commission_rate = 0.10` and calculates `commission_ngn` from the database's agreed booking price. After Paystack verifies a successful payment, the payment ledger is marked paid and the admin summary can total recorded commission.

**Important distinction:** this version records LocalFix's 10% commission in the ledger; it does not automatically transfer the remaining 90% to a provider's bank account. Provider payouts or automatic split settlements require a separate payout/split-payment design, verified provider bank details, and additional reconciliation/refund controls. Paystack processing fees may also apply.

## Before accepting real money
- Test with Paystack test keys first.
- Have the provider payout and refund/cancellation policies decided.
- Confirm whether the 10% is calculated before or after gateway fees.
- Add server-side booking status transitions, payout/split logic, reconciliation, and production security tests.
- Never expose `SUPABASE_SERVICE_ROLE_KEY` or `PAYSTACK_SECRET_KEY` in browser code or share them in chat.
- This starter has not been audited or deployed; do not treat it as production-ready without testing.
