import crypto from 'node:crypto';

export default async (request) => {
  if (request.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const secret = Netlify.env.get('PAYSTACK_SECRET_KEY');
  const supabaseUrl = Netlify.env.get('SUPABASE_URL');
  const serviceKey = Netlify.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!secret || !supabaseUrl || !serviceKey) return new Response('Not configured', { status: 503 });

  const rawBody = await request.text();
  const signature = request.headers.get('x-paystack-signature') || '';
  const expected = crypto.createHmac('sha512', secret).update(rawBody).digest('hex');
  const a = Buffer.from(signature, 'utf8');
  const b = Buffer.from(expected, 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return new Response('Invalid signature', { status: 401 });

  let event;
  try { event = JSON.parse(rawBody); } catch { return new Response('Bad JSON', { status: 400 }); }
  if (event.event !== 'charge.success' || !event.data?.reference) return new Response('Ignored', { status: 200 });

  try {
    const reference = String(event.data.reference);
    const gatewayResponse = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { authorization: `Bearer ${secret}` }
    });
    const gateway = await gatewayResponse.json();
    if (!gatewayResponse.ok || !gateway.status || gateway.data?.status !== 'success') return new Response('Payment not verified', { status: 400 });

    const headers = { apikey: serviceKey, authorization: `Bearer ${serviceKey}`, 'content-type': 'application/json' };
    const lookup = await fetch(`${supabaseUrl}/rest/v1/payments?provider_reference=eq.${encodeURIComponent(reference)}&select=id,amount_ngn,currency,status`, { headers });
    if (!lookup.ok) return new Response('Could not load payment', { status: 500 });
    const rows = await lookup.json();
    const payment = rows[0];
    if (!payment) return new Response('Unknown payment reference', { status: 404 });
    if (payment.status === 'paid') return new Response('Already processed', { status: 200 });
    const expectedKobo = Math.round(Number(payment.amount_ngn) * 100);
    if (gateway.data.currency !== 'NGN' || Number(gateway.data.amount) !== expectedKobo || payment.currency !== 'NGN') {
      return new Response('Amount or currency mismatch', { status: 400 });
    }

    const update = await fetch(`${supabaseUrl}/rest/v1/payments?provider_reference=eq.${encodeURIComponent(reference)}&status=eq.pending`, {
      method: 'PATCH',
      headers: { ...headers, Prefer: 'return=minimal' },
      body: JSON.stringify({ status: 'paid' })
    });
    if (!update.ok) return new Response('Could not record payment', { status: 500 });
    return new Response('OK', { status: 200 });
  } catch {
    return new Response('Webhook processing failed', { status: 500 });
  }
};
