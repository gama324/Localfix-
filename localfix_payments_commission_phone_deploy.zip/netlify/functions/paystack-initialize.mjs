import crypto from 'node:crypto';

const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }
});

export default async (request) => {
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const supabaseUrl = Netlify.env.get('SUPABASE_URL');
  const anonKey = Netlify.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Netlify.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const paystackSecret = Netlify.env.get('PAYSTACK_SECRET_KEY');
  const siteUrl = Netlify.env.get('SITE_URL') || new URL(request.url).origin;
  if (!supabaseUrl || !anonKey || !serviceKey || !paystackSecret) {
    return json({ error: 'Payment service is not configured yet.' }, 503);
  }

  const token = request.headers.get('authorization')?.replace(/^Bearer\s+/i, '');
  if (!token) return json({ error: 'Please sign in before paying.' }, 401);

  try {
    const authResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
      headers: { apikey: anonKey, authorization: `Bearer ${token}` }
    });
    if (!authResponse.ok) return json({ error: 'Your session is invalid. Please sign in again.' }, 401);
    const user = await authResponse.json();
    const body = await request.json();
    const bookingId = body.bookingId;
    if (typeof bookingId !== 'string' || !/^[0-9a-f-]{36}$/i.test(bookingId)) {
      return json({ error: 'A valid booking ID is required.' }, 400);
    }

    const headers = { apikey: serviceKey, authorization: `Bearer ${serviceKey}`, 'content-type': 'application/json' };
    const bookingResponse = await fetch(`${supabaseUrl}/rest/v1/bookings?id=eq.${encodeURIComponent(bookingId)}&select=id,customer_id,provider_id,status,agreed_amount_ngn`, { headers });
    if (!bookingResponse.ok) return json({ error: 'Could not load booking.' }, 502);
    const rows = await bookingResponse.json();
    const booking = rows[0];
    if (!booking) return json({ error: 'Booking not found.' }, 404);
    if (booking.customer_id !== user.id) return json({ error: 'You can only pay for your own booking.' }, 403);
    if (!['accepted', 'in_progress'].includes(booking.status)) return json({ error: 'The provider must accept the booking before payment.' }, 409);
    const amountNaira = Number(booking.agreed_amount_ngn);
    if (!Number.isFinite(amountNaira) || amountNaira <= 0) return json({ error: 'The provider must set an agreed price before payment.' }, 409);
    const amountKobo = Math.round(amountNaira * 100);
    if (!Number.isSafeInteger(amountKobo) || amountKobo <= 0) return json({ error: 'Booking amount is invalid.' }, 400);

    const oldResponse = await fetch(`${supabaseUrl}/rest/v1/payments?booking_id=eq.${booking.id}&select=id,status`, { headers });
    if (!oldResponse.ok) return json({ error: 'Could not check payment record.' }, 502);
    const oldRows = await oldResponse.json();
    if (oldRows[0]?.status === 'paid') return json({ error: 'This booking has already been paid.' }, 409);

    const reference = `lf_${crypto.randomUUID().replaceAll('-', '')}`;
    const commissionNaira = Math.round(amountNaira * 0.10 * 100) / 100;
    const payment = {
      booking_id: booking.id,
      customer_id: booking.customer_id,
      provider_id: booking.provider_id,
      amount_ngn: amountNaira,
      commission_rate: 0.10,
      commission_ngn: commissionNaira,
      currency: 'NGN',
      payment_provider: 'paystack',
      provider_reference: reference,
      status: 'pending'
    };
    const saveUrl = oldRows[0]
      ? `${supabaseUrl}/rest/v1/payments?booking_id=eq.${booking.id}`
      : `${supabaseUrl}/rest/v1/payments`;
    const saveResponse = await fetch(saveUrl, {
      method: oldRows[0] ? 'PATCH' : 'POST',
      headers: { ...headers, Prefer: 'return=minimal' },
      body: JSON.stringify(payment)
    });
    if (!saveResponse.ok) return json({ error: 'Could not create payment record.' }, 502);

    const gatewayResponse = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: { authorization: `Bearer ${paystackSecret}`, 'content-type': 'application/json' },
      body: JSON.stringify({
        email: user.email,
        amount: amountKobo,
        currency: 'NGN',
        reference,
        callback_url: `${siteUrl}/payment-return.html`,
        metadata: { booking_id: booking.id, platform: 'LocalFix' }
      })
    });
    const gateway = await gatewayResponse.json();
    if (!gatewayResponse.ok || !gateway.status || !gateway.data?.authorization_url) {
      await fetch(`${supabaseUrl}/rest/v1/payments?provider_reference=eq.${reference}`, {
        method: 'PATCH', headers: { ...headers, Prefer: 'return=minimal' }, body: JSON.stringify({ status: 'failed' })
      });
      return json({ error: 'The payment provider could not start checkout. Please try again.' }, 502);
    }
    return json({ authorizationUrl: gateway.data.authorization_url, reference });
  } catch {
    return json({ error: 'Unexpected payment error. Please try again.' }, 500);
  }
};
